-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 29, 2021 at 02:57 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hms`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE IF NOT EXISTS `adminlogin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adminname` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`id`, `adminname`, `password`) VALUES
(1, 'admin', 'admin@123');

-- --------------------------------------------------------

--
-- Table structure for table `bookingparty`
--

CREATE TABLE IF NOT EXISTS `bookingparty` (
  `fullname` varchar(50) NOT NULL,
  `emailid` varchar(50) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `date` varchar(20) NOT NULL,
  `selects` varchar(20) NOT NULL,
  PRIMARY KEY (`fullname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookingparty`
--

INSERT INTO `bookingparty` (`fullname`, `emailid`, `phone`, `date`, `selects`) VALUES
('Divya BS', 'divyabs12@gmail.com', '0989 434 5', '2020-12-19', 'Reception'),
('Charulatha J', 'charulatha@gmail.com', '7890653421', '2020-12-05', 'Wedding'),
('Srinidhi A', 'srinu@gmail.com', '971512089', '2020-10-31', 'Reception'),
('BS divya', 'divyabs12@gmail.com', '6789012543', '2020-11-08', 'Reception'),
('Saraswathi J', 'saraswathijana@gmail.com', '9894356781', '2020-11-08', 'Reception'),
('Virat', 'virat@gmail.com', '8940865214', '2020-11-06', 'Wedding'),
('Janardhanan', 'charu@gmail.com', '0989 434 5', '2020-12-06', 'Wedding'),
('Priyadharshini ', 'priyadharshini@gmail.com', '8906523451', '2020-11-01', 'Reception'),
('Sam Curran R', 'samcur@gmail.com', '0989 434 5', '2020-11-18', 'Wedding'),
('Karan', 'karan@gmail.com', '0989 434 5', '2020-11-21', 'Conference'),
('Karthiga Priya', 'karthigapriya@gmail.com', '0989 434 5', '2020-12-20', 'Reception'),
('lop', 'lop@gmail.com', '9994097023', '2021-05-30', 'Reception');

-- --------------------------------------------------------

--
-- Table structure for table `bookingroom`
--

CREATE TABLE IF NOT EXISTS `bookingroom` (
  `fullname` varchar(50) NOT NULL,
  `emailid` varchar(50) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `Indate` varchar(20) NOT NULL,
  `Outdate` varchar(20) NOT NULL,
  `selects` varchar(10) NOT NULL,
  PRIMARY KEY (`fullname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookingroom`
--

INSERT INTO `bookingroom` (`fullname`, `emailid`, `phone`, `Indate`, `Outdate`, `selects`) VALUES
('Divya BS', 'divyabs@gmail.com', '2147483647', '2020-11-08', '2020-11-03', '2'),
('Srinidhi', 'Srinidhi@gmail.com', '2147483647', '2020-10-16', '2020-10-10', '3'),
('R JANA', 'rjana1968@gmail.com', '9894345045', '2020-10-31', '2020-11-02', '2'),
('Losliya', 'losliya@gmail.com', '8970762134', '2020-11-06', '2020-11-03', '2'),
('Karthiga', 'karthiga@gmail.com', '9894354231', '2020-11-26', '2020-11-27', '3'),
('Dharani', 'dharani@gmail.com', '9894598762', '2020-12-19', '2020-11-20', '1'),
('Kannan', 'kannan@gmail.com', '9876745231', '2020-12-19', '2020-12-20', '1'),
('Preethi', 'preethi@gmail.com', '0989 434 5', '2020-12-25', '2020-12-26', '3'),
('Shivalini', 'shivalini@gmail.com', '9876543210', '2020-12-11', '2020-12-12', '3'),
('Janardhanan', 'jana@gmail.com', '0989 434 5', '2020-12-11', '2020-11-12', '3'),
('Chellamal', 'chellamal@gmail.com', '9867906543', '2020-11-18', '2020-11-19', '1'),
('Janardhanan R', 'jana@gmail.com', '0989 434 5', '2020-11-18', '2020-11-19', '1'),
('Janardhanan R P', 'cj@gmail.com', '0989 434 5', '2020-11-18', '2020-11-19', '1'),
('lpo', 'lop@gmail.com', '9894345045', '2021-05-30', '2021-05-31', '2');

-- --------------------------------------------------------

--
-- Table structure for table `bookingtable`
--

CREATE TABLE IF NOT EXISTS `bookingtable` (
  `fullname` varchar(50) NOT NULL,
  `emailid` varchar(50) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `date` varchar(100) NOT NULL,
  `Intime` varchar(10) NOT NULL,
  `selects` varchar(10) NOT NULL,
  PRIMARY KEY (`fullname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookingtable`
--

INSERT INTO `bookingtable` (`fullname`, `emailid`, `phone`, `date`, `Intime`, `selects`) VALUES
('Charulatha J', 'charu@gmail.com', '8740432650', '2020-11-18', '16:10', '1'),
('Janardhanan', 'cj@gmail.com', '0989 434 5', '2020-11-18', '16:10', '1'),
('Kavi Priya', 'kavipriya@gmail.com', '0989 434 5', '2020-11-19', '17:51', '1'),
('Sam Curran', 'samcur@gmail.com', '0989 434 5', '2020-11-19', '17:51', '1'),
('lop', 'lop@gmail.com', '9994097023', '2021-05-30', '10:30', '2');

-- --------------------------------------------------------

--
-- Table structure for table `mytable`
--

CREATE TABLE IF NOT EXISTS `mytable` (
  `id` int(11) NOT NULL,
  `name` varchar(11) NOT NULL,
  `price` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `total price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mytable`
--

INSERT INTO `mytable` (`id`, `name`, `price`, `qty`, `total price`) VALUES
(1, 'Dosa', 50, 3, 150),
(2, 'idly', 25, 2, 50),
(3, 'Naan', 45, 2, 90),
(4, 'Sandwich', 70, 1, 70),
(5, 'Salad', 60, 1, 60),
(6, 'FrenchToast', 70, 2, 140);

-- --------------------------------------------------------

--
-- Table structure for table `mytable1`
--

CREATE TABLE IF NOT EXISTS `mytable1` (
  `id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `price` int(10) NOT NULL,
  `qty` int(10) NOT NULL,
  `total price` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mytable1`
--

INSERT INTO `mytable1` (`id`, `name`, `price`, `qty`, `total price`) VALUES
(1, 'Biriyani', 150, 2, 300),
(2, 'Meals', 100, 2, 200),
(3, 'Curd Rice', 50, 1, 50),
(4, 'Burger', 75, 2, 150),
(5, 'Fried Rice', 100, 1, 100),
(6, 'Shawarma', 100, 2, 200),
(1, 'Biriyani', 150, 2, 300),
(2, 'Meals', 100, 2, 200),
(3, 'Curd Rice', 50, 1, 50),
(4, 'Burger', 75, 2, 150),
(5, 'Fried Rice', 100, 1, 100),
(6, 'Shawarma', 100, 2, 200);

-- --------------------------------------------------------

--
-- Table structure for table `mytable2`
--

CREATE TABLE IF NOT EXISTS `mytable2` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `price` int(10) NOT NULL,
  `qty` int(10) NOT NULL,
  `total price` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `mytable2`
--

INSERT INTO `mytable2` (`id`, `name`, `price`, `qty`, `total price`) VALUES
(1, 'Noodles', 100, 1, 100),
(2, 'Plain naan', 150, 1, 150),
(3, 'Pizza', 125, 1, 125),
(4, 'Fried Rice', 120, 1, 120),
(5, 'Chola puri', 90, 2, 180),
(6, 'Paneer Tikka', 150, 2, 300);

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE IF NOT EXISTS `usertable` (
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`name`, `email`, `password`) VALUES
('Sam', 'sam@gmail.com', '12345'),
('tom', 'tom@gmail.com', '12345'),
('Janardhanan R', 'rjana1968@gmail.com', 'jskc3193'),
('Srinidhi', 'sri@gmail.com', 'pet'),
('Divya BS', 'divyabs@gmail.com', 'divya'),
('Srinidhi Anandh', 'sran@gmail.com', 'sri'),
('R Jana', 'rjana1968@gmail.com', 'jskc'),
('CharuLatha J', 'cj@gmail.com', '12345'),
('Virat', 'virat@gmail.com', 'virat'),
('Sajji', 'sajji@gmail.com', 'sajji'),
('Sajjithra S A', 'sajjithra@gmail.com', 'sajjithra'),
('Kajal', 'kajal@gmail.com', 'kajal'),
('Priyadharshini', 'priyadharshini@gmail.com', '12345'),
('Charu', 'cj@gmail.com', '12345'),
('Karthiga', 'karthiga@gmail.com', '12345'),
('Preethi', 'preethi@gmail.com', '12345'),
('Murugan', 'murugan@gmail.com', '123456'),
('Dharani', 'dharani@gmail.com', '12345'),
('Kannan', 'kannan@gmail.com', '12345'),
('Shivalini', 'shivalini@gmail.com', '12345'),
('Kavirathi R', 'kavirathi@gmail.com', '123456'),
('Srinidhi S A', 'srnidhi@gmail.com', '123456'),
('Kavi Priya', 'kavipriya@gmail.com', '123456'),
('Karthiga Priya', 'karthigapriya@gmai.com', '123456'),
('Azee', 'azee@gmail.com', '12345');
